(() => {
  'use strict';

  function getNotasPageType(doc = document) {
    try {
      const path = (location.pathname || '').toLowerCase();
      if (path.includes('/notas/recebidas')) return 'recebidas';
      if (path.includes('/notas/emitidas')) return 'emitidas';
      const h2 = (doc.querySelector('h2')?.textContent || '').toLowerCase();
      if (h2.includes('recebidas')) return 'recebidas';
      if (h2.includes('emitidas')) return 'emitidas';
      const txt = (doc.body && doc.body.innerText) ? doc.body.innerText.toLowerCase() : '';
      if (txt.includes('notas recebidas') || txt.includes('nfs-e recebidas')) return 'recebidas';
      if (txt.includes('notas emitidas') || txt.includes('nfs-e emitidas')) return 'emitidas';
    } catch {}
    return 'desconhecida';
  }

  let ACTIVE_NOTAS_PAGE_TYPE = getNotasPageType(document);

  function keyByPage(base) {
    // sempre calcula pelo tipo atual (pode mudar via navegação interna)
    const t = getNotasPageType(document);
    ACTIVE_NOTAS_PAGE_TYPE = t;
    return `${base}_${t}`;
  }

  function notasLabel() {
    return getNotasPageType(document) === 'emitidas' ? 'Notas emitidas' : 'Notas recebidas';
  }

  function conferenciaLabel() {
    return getNotasPageType(document) === 'emitidas' ? 'Conferência NFS-e Emitidas' : 'Conferência NFS-e Recebidas';
  }

  /**
   * Conferência NFS-e Recebidas (multi-página)
   *
   * Principais ajustes para o portal do Emissor Nacional:
   * - Multi-página sem "clicar" em javascript: (evita CSP). Em vez disso, faz fetch das páginas ?pg=N.
   * - Extração de XML URL usando seletor específico: /Notas/Download/NFSe/...
   * - Leitura de retenções mais robusta: considera TODAS as ocorrências das tags (não só a primeira).
   * - Download de todos os XMLs em um ÚNICO ZIP (sem dependências externas): implementa ZIP "store" (sem compressão).
   */

  const EXT_VERSION = '1.9.0';

  // Se o portal trocar Recebidas <-> Emitidas via navegação interna (pushState),
  // precisamos separar os caches e reinicializar os mapas/sets em memória.
  function resetInMemoryCachesForPageType() {
    CANCELED_KEYS.clear();
    SUBSTITUTED_KEYS.clear();
    RESULTS_BY_XML_URL.clear();
    NOTE_CACHE.clear();
    RET_BY_ID.clear();
  }

  function currentNotasType() {
    return getNotasPageType(document);
  }

  async function ensureCorrectPageType() {
    const t = currentNotasType();
    if (!t || t === 'desconhecida') return;
    if (t === ACTIVE_NOTAS_PAGE_TYPE) return;

    ACTIVE_NOTAS_PAGE_TYPE = t;
    resetInMemoryCachesForPageType();
    // recarrega caches do storage para o tipo atual
    loadCanceledKeys();
    loadSubstitutedKeys();
    loadNoteCache();
    loadRetById();
    loadResultsCache();
    // reforço via chrome.storage.local (assíncrono)
    try {
      await loadCanceledKeysFromStorage();
      await loadNoteCacheFromStorage();
    } catch {}
    // reaplica tags na nova tela
    try { reapplyTagsFromCaches(); } catch {}
  }

  // observa navegação interna
  (function hookHistory() {
    try {
      const _ps = history.pushState;
      history.pushState = function(...args) {
        const r = _ps.apply(this, args);
        setTimeout(() => { ensureCorrectPageType(); }, 50);
        return r;
      };
      const _rs = history.replaceState;
      history.replaceState = function(...args) {
        const r = _rs.apply(this, args);
        setTimeout(() => { ensureCorrectPageType(); }, 50);
        return r;
      };
      window.addEventListener('popstate', () => setTimeout(() => { ensureCorrectPageType(); }, 50));
    } catch {}
    // fallback: checa de tempos em tempos
    setInterval(() => { ensureCorrectPageType(); }, 800);
  })();

  const STATE = {
    running: false,
    stopRequested: false,
    selectedRow: null,
    lastSummary: null,
    allTotals: null,
  };

  // Resultados indexados por URL do XML (funciona entre páginas)
  
  // Pequena pausa para não travar o portal (yield)
  const delay = (ms) => new Promise(res => setTimeout(res, ms));
const RESULTS_BY_XML_URL = new Map();

  // Chaves (ID) de notas confirmadas como canceladas (via visualização)
  const CANCELED_KEYS = new Set();

  // Chaves (ID) de notas marcadas como substituídas
  const SUBSTITUTED_KEYS = new Set();


  // Preferências de UI (minimizar/expandir painel)
  const UI_COLLAPSE_KEY = 'nfse_retencao_panel_collapsed';
  // Posição do painel (arrastável)
  const UI_POS_KEY = 'nfse_retencao_panel_pos_v1';

  // Persistência (para manter tags ao trocar de página)
  // Importante: o portal pode navegar entre Recebidas/Emitidas sem recarregar (pushState).
  // Por isso, as chaves de cache são geradas dinamicamente pelo tipo de página atual.
  function persistKey(base) {
    return keyByPage(base);
  }
  function PERSIST_KEY_CANCELED() { return persistKey('nfse_ext_canceled_keys_v1'); }
  function PERSIST_KEY_SUBSTITUTED() { return persistKey('nfse_ext_substituted_keys_v1'); }
  function PERSIST_KEY_RESULTS() { return persistKey('nfse_ext_results_by_xml_v1'); }
  // Cache persistente por NOTA (mais estável que por URL)
  function PERSIST_KEY_NOTE_CACHE() { return persistKey('nfse_ext_note_cache_v1'); }
  function PERSIST_KEY_RET_BY_ID() { return persistKey('nfse_ext_ret_by_id_v1'); }
const RET_BY_ID = new Map(); // notaId -> { badgeText, kind, title, ts }

const NOTE_CACHE = new Map(); // key: notaId (string) -> { ret?:{badgeText,kind,title}, cancel?:true, subst?:true, num?:string, ts:number }

function loadNoteCache() {
  try {
    const raw = localStorage.getItem(PERSIST_KEY_NOTE_CACHE());
    const obj = safeJsonParse(raw);
    if (!obj || typeof obj !== 'object') return;
    for (const [k, v] of Object.entries(obj)) {
      if (!k || !v) continue;
      NOTE_CACHE.set(String(k), v);
    }
  } catch {}
}

async function loadNoteCacheFromStorage() {
  const raw = await storageGet(PERSIST_KEY_NOTE_CACHE());
  const obj = safeJsonParse(raw);
  if (!obj || typeof obj !== 'object') return;
  let changed = false;
  for (const [k, v] of Object.entries(obj)) {
    if (!k || !v) continue;
    if (!NOTE_CACHE.has(String(k))) { NOTE_CACHE.set(String(k), v); changed = true; }
  }
  if (changed) saveNoteCacheSoon();
}

let noteSaveTimer = null;
function saveNoteCacheSoon() {
  if (noteSaveTimer) return;
  noteSaveTimer = setTimeout(() => {
    noteSaveTimer = null;
    try {
      const out = {};
      let i = 0;
      for (const [k, v] of NOTE_CACHE.entries()) {
        if (!k || !v) continue;
        out[k] = v;
        i++;
        if (i > 2500) break; // limite de segurança
      }
      const payload = JSON.stringify(out);
      localStorage.setItem(PERSIST_KEY_NOTE_CACHE(), payload);
      storageSet(PERSIST_KEY_NOTE_CACHE(), payload);
    } catch {}
  }, 120);
}

function loadRetById() {
  try {
    const raw = localStorage.getItem(PERSIST_KEY_RET_BY_ID());
    const obj = safeJsonParse(raw);
    if (!obj || typeof obj !== 'object') return;
    for (const [k, v] of Object.entries(obj)) {
      if (!k || !v) continue;
      RET_BY_ID.set(String(k), v);
    }
  } catch {}
}

async function loadRetByIdFromStorage() {
  const raw = await storageGet(PERSIST_KEY_RET_BY_ID());
  const obj = safeJsonParse(raw);
  if (!obj || typeof obj !== 'object') return;
  let changed = false;
  for (const [k, v] of Object.entries(obj)) {
    if (!k || !v) continue;
    const ks = String(k);
    if (!RET_BY_ID.has(ks)) { RET_BY_ID.set(ks, v); changed = true; }
  }
  if (changed) saveRetByIdSoon();
}

let retSaveTimer = null;
function saveRetByIdSoon() {
  if (retSaveTimer) return;
  retSaveTimer = setTimeout(() => {
    retSaveTimer = null;
    try {
      const out = {};
      let i = 0;
      for (const [k, v] of RET_BY_ID.entries()) {
        if (!k || !v) continue;
        out[k] = v;
        i++;
        if (i > 2500) break;
      }
      const payload = JSON.stringify(out);
      localStorage.setItem(PERSIST_KEY_RET_BY_ID(), payload);
      storageSet(PERSIST_KEY_RET_BY_ID(), payload);
    } catch {}
  }, 200);
}


function saveRetByIdNow() {
  try {
    const out = {};
    let i = 0;
    for (const [k, v] of RET_BY_ID.entries()) {
      if (!k || !v) continue;
      out[k] = v;
      i++;
      if (i > 2500) break;
    }
    const payload = JSON.stringify(out);
    localStorage.setItem(PERSIST_KEY_RET_BY_ID(), payload);
    storageSet(PERSIST_KEY_RET_BY_ID(), payload);
  } catch {}
}


function retByIdSet(notaKey, badgeText, kind, title) {
  if (!notaKey) return;
  const k = String(notaKey);
  RET_BY_ID.set(k, { badgeText, kind, title, ts: Date.now() });
  saveRetByIdSoon();
}


function saveNoteCacheNow() {
  try {
    const out = {};
    let i = 0;
    for (const [k, v] of NOTE_CACHE.entries()) {
      if (!k || !v) continue;
      out[k] = v;
      i++;
      if (i > 2500) break;
    }
    const payload = JSON.stringify(out);
    localStorage.setItem(PERSIST_KEY_NOTE_CACHE(), payload);
    storageSet(PERSIST_KEY_NOTE_CACHE(), payload);
  } catch {}
}


function noteCacheSetRet(notaKey, badgeText, kind, title) {
  if (!notaKey) return;
  const k = String(notaKey);
  const prev = NOTE_CACHE.get(k) || {};
  NOTE_CACHE.set(k, { ...prev, ret: { badgeText, kind, title }, ts: Date.now() });
  saveNoteCacheSoon();
}

function noteCacheSetCanceled(notaKey) {
  if (!notaKey) return;
  const k = String(notaKey);
  const prev = NOTE_CACHE.get(k) || {};
  NOTE_CACHE.set(k, { ...prev, cancel: true, ts: Date.now() });
  saveNoteCacheSoon();
}

function noteCacheSetSubstituted(notaKey) {
  if (!notaKey) return;
  const k = String(notaKey);
  const prev = NOTE_CACHE.get(k) || {};
  NOTE_CACHE.set(k, { ...prev, subst: true, ts: Date.now() });
  saveNoteCacheSoon();
}

function noteCacheSetNumeroNFSe(notaKey, numero) {
  const num = String(numero || '').trim();
  if (!notaKey || !num) return;
  const k = String(notaKey);
  const prev = NOTE_CACHE.get(k) || {};
  NOTE_CACHE.set(k, { ...prev, num, ts: Date.now() });
  saveNoteCacheSoon();
}


  // (Opcional) reforço de persistência via chrome.storage.local (não depende do localStorage do site)
  async function storageGet(key) {
    try {
      if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
        const obj = await chrome.storage.local.get([key]);
        return obj ? obj[key] : null;
      }
    } catch {}
    return null;
  }

  async function storageSet(key, value) {
    try {
      if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
        await chrome.storage.local.set({ [key]: value });
        return true;
      }
    } catch {}
    return false;
  }

  function safeJsonParse(s) {
    try { return JSON.parse(s); } catch { return null; }
  }

  function loadCanceledKeys() {
    try {
      const raw = localStorage.getItem(PERSIST_KEY_CANCELED());
      const arr = safeJsonParse(raw);
      if (Array.isArray(arr)) {
        arr.forEach(k => { if (k) CANCELED_KEYS.add(String(k)); });
      }
    } catch {}
  }

  
  async function loadCanceledKeysFromStorage() {
    const raw = await storageGet(PERSIST_KEY_CANCELED());
    const arr = safeJsonParse(raw);
    if (Array.isArray(arr)) {
      let changed = false;
      for (const k of arr) {
        if (!k) continue;
        const s = String(k);
        if (!CANCELED_KEYS.has(s)) { CANCELED_KEYS.add(s); changed = true; }
      }
      if (changed) saveCanceledKeysSoon();
    }
  }
let canceledSaveTimer = null;
  function saveCanceledKeysSoon() {
    if (canceledSaveTimer) return;
    canceledSaveTimer = setTimeout(() => {
      canceledSaveTimer = null;
      try {
        const payload = JSON.stringify(Array.from(CANCELED_KEYS));
        localStorage.setItem(PERSIST_KEY_CANCELED(), payload);
        storageSet(PERSIST_KEY_CANCELED(), payload);
      } catch {}
    }, 300);
  }

  function loadResultsCache() {
    try {
      const raw = localStorage.getItem(PERSIST_KEY_RESULTS());
      const obj = safeJsonParse(raw);
      if (!obj || typeof obj !== 'object') return;
      for (const [xmlUrl, v] of Object.entries(obj)) {
        if (!xmlUrl || !v) continue;
        RESULTS_BY_XML_URL.set(xmlUrl, v);
        }
    } catch {}
  }

  let resultsSaveTimer = null;
  
  async function loadResultsCacheFromStorage() {
    const raw = await storageGet(PERSIST_KEY_RESULTS());
    const obj = safeJsonParse(raw);
    if (!obj || typeof obj !== 'object') return;
    let changed = false;
    for (const [xmlUrl, v] of Object.entries(obj)) {
      if (!xmlUrl || !v) continue;
      if (!RESULTS_BY_XML_URL.has(xmlUrl)) { RESULTS_BY_XML_URL.set(xmlUrl, v); changed = true; }
    }
    if (changed) saveResultsSoon();
  }
function saveResultsSoon() {
    if (resultsSaveTimer) return;
    resultsSaveTimer = setTimeout(() => {
      resultsSaveTimer = null;
      try {
        // salva só o necessário (evita estourar localStorage)
        const out = {};
        let i = 0;
        for (const [k, v] of RESULTS_BY_XML_URL.entries()) {
          if (!k || !v) continue;
          out[k] = v;
          i++;
          if (i > 800) break; // limite de segurança
        }
        const payload = JSON.stringify(out);
        localStorage.setItem(PERSIST_KEY_RESULTS(), payload);
        storageSet(PERSIST_KEY_RESULTS(), payload);
      } catch {}
    }, 500);
  }

  
function saveResultsNow() {
  try {
    const out = {};
    let i = 0;
    for (const [k, v] of RESULTS_BY_XML_URL.entries()) {
      if (!k || !v) continue;
      out[k] = v;
      i++;
      if (i > 2500) break;
    }
    const payload = JSON.stringify(out);
    localStorage.setItem(PERSIST_KEY_RESULTS(), payload);
    storageSet(PERSIST_KEY_RESULTS(), payload);
  } catch {}
}

  function loadSubstitutedKeys() {
    try {
      const raw = localStorage.getItem(PERSIST_KEY_SUBSTITUTED());
      const arr = safeJsonParse(raw);
      if (Array.isArray(arr)) {
        arr.forEach(k => { if (k) SUBSTITUTED_KEYS.add(String(k)); });
      }
    } catch {}
  }

  async function loadSubstitutedKeysFromStorage() {
    const raw = await storageGet(PERSIST_KEY_SUBSTITUTED());
    const arr = safeJsonParse(raw);
    if (!Array.isArray(arr)) return;
    let changed = false;
    for (const k of arr) {
      const s = String(k || '');
      if (!s) continue;
      if (!SUBSTITUTED_KEYS.has(s)) { SUBSTITUTED_KEYS.add(s); changed = true; }
    }
    if (changed) saveSubstitutedKeysSoon();
  }

  let substSaveTimer = null;
  function saveSubstitutedKeysSoon() {
    if (substSaveTimer) return;
    substSaveTimer = setTimeout(() => {
      substSaveTimer = null;
      try {
        const payload = JSON.stringify(Array.from(SUBSTITUTED_KEYS));
        localStorage.setItem(PERSIST_KEY_SUBSTITUTED(), payload);
        storageSet(PERSIST_KEY_SUBSTITUTED(), payload);
      } catch {}
    }, 120);
  }


function applyCachedTagsToCurrentPage() {
    if (!looksLikeNotasPage()) return;
    const rows = findRows(document);
    for (const row of rows) {
      const xmlUrl = extractXmlUrlFromRow(row);
      if (!xmlUrl) continue;

      // Número real da NFS-e (cache por nota)
      const nk_num = extractNotaKeyFromUrl(xmlUrl);
      const sk_num = extractStableRowKeyFromRow(row, xmlUrl) || nk_num;
      let nc_num = sk_num ? NOTE_CACHE.get(String(sk_num)) : null;
      if (!nc_num && nk_num) nc_num = NOTE_CACHE.get(String(nk_num));
      if (nc_num && nc_num.num) {
        setNFSeNumeroBadge(row, nc_num.num);
      }

      // garante botão XML
      ensureRowXmlButton(row, xmlUrl);

            // se a coluna Situação já indica cancelada, salva no cache para manter ao trocar de página
      if (isCanceledBySituacaoCell(row)) {
        const k0n = extractNotaKeyFromUrl(xmlUrl);
        const k0 = extractStableRowKeyFromRow(row, xmlUrl) || k0n;
        if (k0) { 
          if (!CANCELED_KEYS.has(k0)) { CANCELED_KEYS.add(k0); saveCanceledKeysSoon(); }
          noteCacheSetCanceled(k0);
          // também salva pelo id numérico se for diferente (para manter compatibilidade com cache antigo)
          if (k0n && k0n !== k0) { noteCacheSetCanceled(k0n); }
          setCancelTag(row, 'Cancelada', 'Situação: cancelada');
        }
      }

// canceladas (cache)
      const keyN = extractNotaKeyFromUrl(xmlUrl);
      const key = extractStableRowKeyFromRow(row, xmlUrl) || keyN;
      let nc2 = key ? NOTE_CACHE.get(String(key)) : null;
      if (!nc2 && keyN) nc2 = NOTE_CACHE.get(String(keyN));
      if (key && (CANCELED_KEYS.has(key) || (keyN && CANCELED_KEYS.has(keyN)) || (nc2 && nc2.cancel))) {
        setCancelTag(row, 'Cancelada', 'Confirmada anteriormente (cache)');
      }

      // retenções (cache) - infalível por NOTA (RET_BY_ID) e fallback para NOTE_CACHE/RESULTS_BY_XML_URL
      const nk = extractNotaKeyFromUrl(xmlUrl);
      const sk = extractStableRowKeyFromRow(row, xmlUrl) || (nk ? String(nk) : null);
      let rb = sk ? RET_BY_ID.get(String(sk)) : null;
      if (!rb && nk) rb = RET_BY_ID.get(String(nk));
      if (rb && rb.badgeText) {
        setBadge(row, rb.badgeText, rb.kind || 'warn', rb.title || '');
      } else {
        let nc = sk ? NOTE_CACHE.get(String(sk)) : null;
        if (!nc && nk) nc = NOTE_CACHE.get(String(nk));
        if (nc && nc.ret && nc.ret.badgeText) {
          setBadge(row, nc.ret.badgeText, nc.ret.kind || 'warn', nc.ret.title || '');
        } else {
          const r = RESULTS_BY_XML_URL.get(xmlUrl);
          if (r && r.badgeText) {
            setBadge(row, r.badgeText, r.kind || 'warn', r.title || '');
          }
        }
      }
    }
  }

  function getPanelCollapsedPref() {
    try {
      return localStorage.getItem(UI_COLLAPSE_KEY) === '1';
    } catch {
      return false;
    }
  }

  function setPanelCollapsedPref(collapsed) {
    try {
      localStorage.setItem(UI_COLLAPSE_KEY, collapsed ? '1' : '0');
    } catch {
      // ignore
    }
  }

  function getPanelPosPref() {
    try {
      const raw = localStorage.getItem(UI_POS_KEY);
      if (!raw) return null;
      const obj = JSON.parse(raw);
      if (!obj || typeof obj !== 'object') return null;
      const left = Number(obj.left);
      const top = Number(obj.top);
      if (!Number.isFinite(left) || !Number.isFinite(top)) return null;
      return { left, top };
    } catch {
      return null;
    }
  }

  function setPanelPosPref(pos) {
    try {
      if (!pos) {
        localStorage.removeItem(UI_POS_KEY);
        return;
      }
      localStorage.setItem(UI_POS_KEY, JSON.stringify({ left: pos.left, top: pos.top }));
    } catch {
      // ignore
    }
  }

  function applyPanelCollapsedState(panel, bodyEl, titleEl, miniEl, btnToggle, btnStopMini) {
    const collapsed = panel && panel.dataset && panel.dataset.collapsed === '1';

    if (collapsed) {
      bodyEl.style.display = 'none';
      panel.style.width = '220px';
      panel.style.padding = '8px 10px';
      titleEl.textContent = panel.dataset.titleCollapsed || titleEl.textContent;
      miniEl.style.display = '';
      btnStopMini.style.display = '';
      btnToggle.textContent = '▸';
      btnToggle.title = 'Expandir painel';
      btnToggle.setAttribute('aria-label', 'Expandir painel');
    } else {
      bodyEl.style.display = '';
      panel.style.width = '340px';
      panel.style.padding = '10px';
      titleEl.textContent = panel.dataset.titleExpanded || titleEl.textContent;
      miniEl.style.display = 'none';
      btnStopMini.style.display = 'none';
      btnToggle.textContent = '—';
      btnToggle.title = 'Minimizar painel';
      btnToggle.setAttribute('aria-label', 'Minimizar painel');
    }
  }

  function clamp(n, min, max) {
    const v = Number(n);
    if (!Number.isFinite(v)) return min;
    return Math.min(Math.max(v, min), max);
  }

  function applySavedPanelPos(panel) {
    const pos = getPanelPosPref();
    if (!pos) return;

    // Converte para posicionamento por left/top (mais fácil para arrastar)
    panel.style.left = `${pos.left}px`;
    panel.style.top = `${pos.top}px`;
    panel.style.right = 'auto';
    panel.style.bottom = 'auto';
  }

  function setPanelPos(panel, left, top) {
    const w = panel.offsetWidth || 340;
    const h = panel.offsetHeight || 120;
    const maxLeft = Math.max(0, window.innerWidth - w);
    const maxTop = Math.max(0, window.innerHeight - h);

    const L = clamp(left, 0, maxLeft);
    const T = clamp(top, 0, maxTop);

    panel.style.left = `${L}px`;
    panel.style.top = `${T}px`;
    panel.style.right = 'auto';
    panel.style.bottom = 'auto';

    setPanelPosPref({ left: L, top: T });
  }

  function installPanelDrag(panel) {
    if (!panel || panel.dataset.dragInstalled === '1') return;
    panel.dataset.dragInstalled = '1';

    // Evita que um arrasto dispare clique/expandir/minimizar
    let suppressNextClick = false;
    panel.addEventListener('click', (ev) => {
      if (!suppressNextClick) return;
      suppressNextClick = false;
      ev.preventDefault();
      ev.stopPropagation();
    }, true);

    panel.addEventListener('mousedown', (ev) => {
      // Só botão esquerdo
      if (ev.button !== 0) return;

      // Prepara arrasto (começa a mover só se houver deslocamento do mouse)
      const rect = panel.getBoundingClientRect();
      const startX = ev.clientX;
      const startY = ev.clientY;
      const offsetX = startX - rect.left;
      const offsetY = startY - rect.top;

      let moved = false;
      let dragStarted = false;
      const prevUserSelect = document.documentElement.style.userSelect;

      const onMove = (e) => {
        const dx = Math.abs(e.clientX - startX);
        const dy = Math.abs(e.clientY - startY);
        if (dx + dy > 2) moved = true;

        // Só inicia de fato quando houver movimento (assim clicar em botões continua funcionando)
        if (moved && !dragStarted) {
          dragStarted = true;
          document.documentElement.style.userSelect = 'none';

          // Converte right/top para left/top no primeiro arrasto
          panel.style.left = `${rect.left}px`;
          panel.style.top = `${rect.top}px`;
          panel.style.right = 'auto';
          panel.style.bottom = 'auto';
        }

        if (!dragStarted) return;

        const left = e.clientX - offsetX;
        const top = e.clientY - offsetY;
        const w = panel.offsetWidth || rect.width;
        const h = panel.offsetHeight || rect.height;
        const maxLeft = Math.max(0, window.innerWidth - w);
        const maxTop = Math.max(0, window.innerHeight - h);

        const L = clamp(left, 0, maxLeft);
        const T = clamp(top, 0, maxTop);

        panel.style.left = `${L}px`;
        panel.style.top = `${T}px`;
      };

      const onUp = () => {
        document.removeEventListener('mousemove', onMove, true);
        document.removeEventListener('mouseup', onUp, true);

        // Só restaura/salva se realmente arrastou
        if (dragStarted) {
          document.documentElement.style.userSelect = prevUserSelect;
          const r = panel.getBoundingClientRect();
          setPanelPosPref({ left: r.left, top: r.top });
          suppressNextClick = true;
        }
      };

      document.addEventListener('mousemove', onMove, true);
      document.addEventListener('mouseup', onUp, true);
      // Não impede o clique aqui; se arrastar, o clique será suprimido no onUp.
    }, true);

    // Mantém visível após resize
    window.addEventListener('resize', () => {
      const pos = getPanelPosPref();
      if (!pos) return;
      setPanelPos(panel, pos.left, pos.top);
    });
  }


  // ------------------------ UI ------------------------
  function ensureUI() {
    if (document.getElementById('nfse-retencao-panel')) return;

    ensureStyles();

    const panel = document.createElement('div');
    panel.id = 'nfse-retencao-panel';
    panel.style.cssText = [
      'position:fixed',
      'top:12px',
      'right:12px',
      'z-index:999999',
      'background:#fff',
      'border:1px solid #ddd',
      'border-radius:12px',
      'box-shadow:0 8px 24px rgba(0,0,0,.12)',
      'padding:10px',
      'width:340px',
      'font:12px/1.35 system-ui, -apple-system, Segoe UI, Roboto, sans-serif',
    ].join(';');

    // estado inicial (persistido)
    panel.dataset.collapsed = getPanelCollapsedPref() ? '1' : '0';
            panel.dataset.titleExpanded = conferenciaLabel();
    panel.dataset.titleCollapsed = 'Conferência NFS-e';

    // Header (sempre visível)
    const header = document.createElement('div');
    header.style.cssText = 'display:flex;align-items:flex-start;justify-content:space-between;gap:8px;margin-bottom:8px;';

    const headerLeft = document.createElement('div');
    headerLeft.style.cssText = 'flex:1;min-width:0;';

    const title = document.createElement('div');
    title.textContent = panel.dataset.titleExpanded;
    title.style.cssText = 'font-weight:700;';

    const mini = document.createElement('div');
    mini.id = 'nfse-retencao-mini';
    mini.style.cssText = 'margin-top:2px;color:#666;font-size:10px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:240px;';
    mini.textContent = '';

    headerLeft.appendChild(title);
    headerLeft.appendChild(mini);

    const headerRight = document.createElement('div');
    headerRight.style.cssText = 'display:flex;align-items:center;gap:6px;flex-shrink:0;';

    const btnStopMini = document.createElement('button');
    btnStopMini.type = 'button';
    btnStopMini.textContent = 'Interromper';
    btnStopMini.style.cssText = [
      'padding:4px 8px',
      'border-radius:10px',
      'border:1px solid #999',
      'background:#f7f7f7',
      'cursor:pointer',
      'font-size:11px',
      'line-height:1'
    ].join(';');
    btnStopMini.title = 'Interromper processamento';

    const btnToggle = document.createElement('button');
    btnToggle.type = 'button';
    btnToggle.textContent = '—';
    btnToggle.style.cssText = [
      'padding:4px 8px',
      'border-radius:10px',
      'border:1px solid #999',
      'background:#fff',
      'cursor:pointer',
      'font-size:11px',
      'line-height:1'
    ].join(';');
    btnToggle.title = 'Minimizar painel';

    headerRight.appendChild(btnStopMini);
    headerRight.appendChild(btnToggle);

    header.appendChild(headerLeft);
    header.appendChild(headerRight);

    // Body (escondido quando minimizado)
    const body = document.createElement('div');
    body.id = 'nfse-retencao-panel-body';

    const subtitle = document.createElement('div');
    subtitle.textContent = 'Painel de conferência do período filtrado: retenções, totalização e exportação de XMLs.';
    subtitle.style.cssText = 'color:#444;margin-bottom:10px;font-size:11px;';

    const buttons = document.createElement('div');
    buttons.style.cssText = 'display:flex;gap:8px;flex-wrap:wrap;margin-bottom:8px;';

    const btnRunPage = document.createElement('button');
    btnRunPage.textContent = 'Analisar página';
    btnRunPage.style.cssText = buttonStyle();

    const btnRunAll = document.createElement('button');
    btnRunAll.textContent = 'Analisar período';
    btnRunAll.style.cssText = buttonStyle();

    const btnZipAll = document.createElement('button');
    btnZipAll.textContent = 'Exportar XMLs';
    btnZipAll.style.cssText = buttonStyle();

    const btnTotalAll = document.createElement('button');
    btnTotalAll.textContent = 'Totalizar valores';
    btnTotalAll.style.cssText = buttonStyle();

    const btnCheckCancel = document.createElement('button');
    btnCheckCancel.textContent = 'Checar canceladas (visualização)';
    btnCheckCancel.style.cssText = buttonStyle();

    const btnDownloadCanceledPdf = document.createElement('button');
    btnDownloadCanceledPdf.textContent = 'Baixar PDFs das canceladas';
    btnDownloadCanceledPdf.style.cssText = buttonStyle();

    const btnStop = document.createElement('button');
    btnStop.textContent = 'Interromper';
    btnStop.style.cssText = buttonStyle(true);

    const btnDownloadSel = document.createElement('button');
    btnDownloadSel.textContent = 'Baixar XML da seleção';
    btnDownloadSel.style.cssText = buttonStyle();

    buttons.appendChild(btnRunPage);
    buttons.appendChild(btnRunAll);
    buttons.appendChild(btnZipAll);
    buttons.appendChild(btnTotalAll);
    buttons.appendChild(btnCheckCancel);
    buttons.appendChild(btnDownloadCanceledPdf);
    buttons.appendChild(btnStop);
    buttons.appendChild(btnDownloadSel);

    const status = document.createElement('div');
    status.id = 'nfse-retencao-status';
                status.textContent = `Acesse “${notasLabel()}” para iniciar.`;
    status.style.cssText = 'color:#111;word-break:break-word;white-space:pre-wrap;';

    const totals = document.createElement('div');
    totals.id = 'nfse-retencao-totals';
    totals.style.cssText = 'margin-top:8px;padding-top:8px;border-top:1px dashed #ddd;color:#111;font-size:11px;white-space:pre-wrap;';
    totals.textContent = 'Totais (página atual): —\nTotais (todas páginas): clique em “Totalizar valores”.';

    const hint = document.createElement('div');
    hint.style.cssText = 'margin-top:8px;color:#666;font-size:11px;';
    hint.textContent = 'Dica: selecione uma nota para baixar apenas o XML dela, ou use “Exportar XMLs” para exportar o período.';

    const foot = document.createElement('div');
    foot.style.cssText = 'margin-top:8px;color:#999;font-size:10px;';
    foot.textContent = 'Observação: a leitura é feita em segundo plano para manter a navegação estável.';

    body.appendChild(subtitle);
    body.appendChild(buttons);
    body.appendChild(status);
    body.appendChild(totals);
    body.appendChild(hint);
    body.appendChild(foot);

    panel.appendChild(header);
    panel.appendChild(body);

    document.body.appendChild(panel);

    // Aplica posição salva (se existir) e instala arrasto em qualquer parte do painel
    applySavedPanelPos(panel);
    installPanelDrag(panel);

    // listeners dos botões (body)
    btnRunPage.addEventListener('click', () => runPage(status));
    btnRunAll.addEventListener('click', () => runAllPages(status));
    btnZipAll.addEventListener('click', () => downloadAllXmlZip(status));
    btnTotalAll.addEventListener('click', () => totalizeAllPages(status));
    btnCheckCancel.addEventListener('click', () => checkCanceladasViaVisualizacao(status));
    btnDownloadCanceledPdf.addEventListener('click', () => downloadCanceledPdfs(status));
    btnStop.addEventListener('click', () => {
      STATE.stopRequested = true;
      setStatus(status, 'Parando...');
    });
    btnDownloadSel.addEventListener('click', () => downloadXmlSelecionada(status));

    // stop no modo minimizado
    btnStopMini.addEventListener('click', (ev) => {
      ev.preventDefault();
      ev.stopPropagation();
      STATE.stopRequested = true;
      setStatus(status, 'Parando...');
    });

    // toggle minimizar/expandir
    function toggleCollapsed() {
      const collapsedNow = panel.dataset.collapsed === '1';
      panel.dataset.collapsed = collapsedNow ? '0' : '1';
      setPanelCollapsedPref(panel.dataset.collapsed === '1');
      applyPanelCollapsedState(panel, body, title, mini, btnToggle, btnStopMini);
    }

    btnToggle.addEventListener('click', (ev) => {
      ev.preventDefault();
      ev.stopPropagation();
      toggleCollapsed();
    });

    // Clique no título expande quando estiver minimizado
    headerLeft.addEventListener('click', (ev) => {
      if (panel.dataset.collapsed === '1') {
        ev.preventDefault();
        ev.stopPropagation();
        toggleCollapsed();
      }
    });

    // aplica estado inicial
    applyPanelCollapsedState(panel, body, title, mini, btnToggle, btnStopMini);
  }

  function buttonStyle(isSecondary = false) {
    return [
      'padding:7px 10px',
      'border-radius:10px',
      'border:1px solid #999',
      `background:${isSecondary ? '#f7f7f7' : '#fff'}`,
      'cursor:pointer',
      'font-size:12px'
    ].join(';');
  }

  function setStatus(el, msg) {
    const m = msg || '';
    if (el) el.textContent = m;

    // Mini status (aparece quando o painel esta minimizado)
    const mini = document.getElementById('nfse-retencao-mini');
    if (mini) {
      const oneLine = String(m).split('\n')[0];
      mini.textContent = oneLine || '';
      mini.title = m;
    }
  }

  // ------------------------ Selection styles ------------------------
  function ensureStyles() {
    if (document.getElementById('nfse-retencao-style')) return;
    const style = document.createElement('style');
    style.id = 'nfse-retencao-style';
    style.textContent = `
      .nfse-retencao-selected-row {
        outline: 2px solid #1a73e8;
        outline-offset: -2px;
      }

      .nfse-nfse-num-host{
        margin-top:4px;
        display:flex;
        gap:6px;
        flex-wrap:wrap;
        align-items:center;
      }
      .nfse-nfse-num-badge{
        display:inline-block;
        padding:2px 8px;
        border-radius:10px;
        font-size:11px;
        font-weight:700;
        /* Mais visível e fácil de identificar */
        background:#fff3cd;
        border:1px solid #ffeeba;
        color:#6c4f00;
        white-space:nowrap;
      }
    `;
    document.head.appendChild(style);
  }

  let selectionHandlerInstalled = false;
  function ensureRowSelectionHandler() {
    if (selectionHandlerInstalled) return;
    selectionHandlerInstalled = true;

    document.addEventListener('click', (ev) => {
      const panel = document.getElementById('nfse-retencao-panel');
      if (panel && panel.contains(ev.target)) return;

      const row = ev.target && ev.target.closest ? ev.target.closest('table tbody tr') : null;
      if (!row) return;
      selectRow(row);
    }, true);
  }

  function selectRow(row) {
    if (STATE.selectedRow && STATE.selectedRow !== row) {
      STATE.selectedRow.classList.remove('nfse-retencao-selected-row');
    }
    STATE.selectedRow = row;
    row.classList.add('nfse-retencao-selected-row');
  }

  // ------------------------ Page detection ------------------------
  function looksLikeNotasPage(doc = document) {
    const txt = (doc.body && doc.body.innerText) ? doc.body.innerText : '';
    const hasText =
      /NFS-e\s+recebidas/i.test(txt) || /NFSe\s+recebidas/i.test(txt) || /Notas\s+recebidas/i.test(txt) ||
      /NFS-e\s+emitidas/i.test(txt)  || /NFSe\s+emitidas/i.test(txt)  || /Notas\s+emitidas/i.test(txt);
    const hasRows = findRows(doc).length > 0;
    return hasText && hasRows;
  }

  function findRows(doc = document) {
    return Array.from(doc.querySelectorAll('table tbody tr'));
  }

  // ------------------------ Extract XML URL (ajustado para o HTML real) ------------------------
  function extractXmlUrlFromRow(row, baseOrigin = location.origin) {
    // Padrão do portal (pelo HTML que você enviou):
    // <a href="/EmissorNacional/Notas/Download/NFSe/<chave>" ...>Download XML</a>
    const direct = row.querySelector('a[href*="/Notas/Download/NFSe/"]');
    if (direct) {
      const href = direct.getAttribute('href') || '';
      if (href) return new URL(href, baseOrigin).toString();
    }

    // Fallback (caso o portal mude levemente)
    const anchors = Array.from(row.querySelectorAll('a[href]'));
    const a = anchors.find(x => {
      const t = (x.textContent || '').trim();
      const title = x.getAttribute('title') || '';
      const href = x.getAttribute('href') || '';
      return /Download\s*XML/i.test(t) || /xml/i.test(title) || /\/Notas\/Download\/NFSe\//i.test(href);
    });
    if (a) {
      const href = a.getAttribute('href') || '';
      if (href && !href.toLowerCase().startsWith('javascript')) {
        return new URL(href, baseOrigin).toString();
      }
    }

    return null;
  }


function extractVisualizarUrlFromRow(row, baseOrigin = location.origin) {
  const a = row.querySelector('a[href*="/Notas/Visualizar/Index/"]');
  if (a) {
    const href = a.getAttribute('href') || '';
    if (href) return new URL(href, baseOrigin).toString();
  }
  return null;
}

function extractNotaKeyFromUrl(urlStr) {
  try {
    const u = new URL(urlStr, location.origin);
    const parts = u.pathname.split('/').filter(Boolean);
    return parts.length ? parts[parts.length - 1] : null;
  } catch {
    return null;
  }
}


function extractStableRowKeyFromRow(row, fallbackUrl) {
  // Chave estável que existe em todas as páginas (mesmo se o portal não renderizar o menu com links)
  // Preferência: atributo data-chave da <tr> (sempre presente na listagem)
  try {
    const k = row && row.getAttribute ? row.getAttribute('data-chave') : null;
    if (k) return String(k);
  } catch {}

  // Fallback: último segmento da URL do XML/Visualizar (id numérico)
  if (fallbackUrl) return extractNotaKeyFromUrl(fallbackUrl);
  return null;
}


function isCanceledBySituacaoCell(row) {
  const td = row.querySelector('td.td-situacao');
  if (!td) return false;
  const img = td.querySelector('img');
  if (!img) return false;
  const title = (img.getAttribute('title') || img.getAttribute('data-original-title') || '').toLowerCase();
  const src = (img.getAttribute('src') || '').toLowerCase();
  return title.includes('cancel') || src.includes('cancel');
}

function isSubstitutedBySituacaoCell(row) {
  const td = row.querySelector('td.td-situacao');
  if (!td) return false;
  const img = td.querySelector('img');
  if (!img) return false;
  const title = (img.getAttribute('title') || img.getAttribute('data-original-title') || '').toLowerCase();
  const src = (img.getAttribute('src') || '').toLowerCase();
  return title.includes('substitu') || src.includes('substitu');
}

function isSubstitutedByCache(row) {
  const xmlUrl = extractXmlUrlFromRow(row);
  if (xmlUrl) {
    const k = extractNotaKeyFromUrl(xmlUrl);
    if (k && SUBSTITUTED_KEYS.has(k)) return true;
    const r = RESULTS_BY_XML_URL.get(xmlUrl);
    if (r && r.substituida) return true;
  }
  return false;
}

function isSubstitutedRow(row) {
  return isSubstitutedBySituacaoCell(row) || isSubstitutedByCache(row);
}

function isExcludedRow(row) {
  return isCanceledRow(row) || isSubstitutedRow(row);
}

function isCanceledByCache(row) {
  // 1) cache por chave (visualização)
  const xmlUrl = extractXmlUrlFromRow(row);
  if (xmlUrl) {
    const k = extractNotaKeyFromUrl(xmlUrl);
    if (k && CANCELED_KEYS.has(k)) return true;
    const r = RESULTS_BY_XML_URL.get(xmlUrl);
    if (r && r.cancelada) return true;
  }
  return false;
}

function isCanceledRow(row) {
  return isCanceledBySituacaoCell(row) || isCanceledByCache(row);
}

  function extractIdFromXmlUrl(xmlUrl) {
    try {
      const u = new URL(xmlUrl);
      const parts = u.pathname.split('/').filter(Boolean);
      return parts[parts.length - 1] || null;
    } catch {
      return null;
    }
  }

  // ------------------------ XML parsing + leitura robusta ------------------------
  function parseXml(xmlText) {
    const doc = new DOMParser().parseFromString(xmlText, 'application/xml');
    const err = doc.querySelector('parsererror');
    if (err) throw new Error('XML inválido (parsererror).');
    return doc;
  }

  function indexXmlTextsByLocalNameLower(xmlDoc) {
    const map = new Map();
    const els = xmlDoc.getElementsByTagName('*');
    for (let i = 0; i < els.length; i++) {
      const el = els[i];
      const name = ((el.localName || el.nodeName || '') + '').toLowerCase();
      if (!name) continue;
      const text = (el.textContent || '').trim();
      if (!text) continue;
      if (!map.has(name)) map.set(name, []);
      map.get(name).push(text);
    }
    return map;
  }

  function normalizeEnum(v) {
    const m = String(v || '').trim().match(/^([0-9]+)/);
    return m ? m[1] : String(v || '').trim();
  }

  function toNumberBR(s) {
    if (!s) return 0;
    // Aceita valores como: 18.216,28 | 330,00 | R$ 1.234,56
    const cleaned = String(s).replace(/ /g, ' ').replace(/\s/g, '').replace(/[^0-9,.-]/g, '');
    const normalized = cleaned.includes(',') ? cleaned.replace(/\./g, '').replace(',', '.') : cleaned;
    const n = Number(normalized);
    return Number.isFinite(n) ? n : 0;
  }

  function sumNumbers(values) {
    let total = 0;
    for (const v of values) total += toNumberBR(v);
    return total;
  }

  // ------------------------ Totalizador (valores das notas) ------------------------

  function formatBRL(n) {
    try {
      return Number(n || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
    } catch {
      const v = Number(n || 0);
      return 'R$ ' + v.toFixed(2).replace('.', ',');
    }
  }

  function extractValorFromRow(row) {
    // No HTML real: <td class="td-valor"> 18.216,28 </td>
    const td = row.querySelector('td.td-valor') || row.querySelector('.td-valor');
    if (!td) return null;
    const txt = (td.textContent || '').trim();
    const v = toNumberBR(txt);
    return Number.isFinite(v) ? v : null;
  }

  function calcTotalsFromRows(rows) {
    let sum = 0;
    let count = 0;
    let missing = 0;
    let canceled = 0;
    let substituted = 0;
    for (const row of rows) {
      if (isCanceledRow(row)) { canceled++; continue; }
      if (isSubstitutedRow(row)) { substituted++; continue; }
      count++;
      const v = extractValorFromRow(row);
      if (v === null) missing++;
      else sum += v;
    }
    return { count, sum, missing, canceled, substituted };
  }

  function calcTotalsFromDocument(doc) {
    return calcTotalsFromRows(findRows(doc));
  }

  function renderTotals() {
    const el = document.getElementById('nfse-retencao-totals');
    if (!el) return;

    const pageTotals = looksLikeNotasPage(document) ? calcTotalsFromDocument(document) : null;
    const allTotals = STATE.allTotals;

    const lines = [];
    if (pageTotals) {
      lines.push(`Totais (página atual): ${pageTotals.count} notas | ${formatBRL(pageTotals.sum)}${pageTotals.canceled ? ` | Canceladas: ${pageTotals.canceled}` : ''}${pageTotals.substituted ? ` | Substituídas: ${pageTotals.substituted}` : ''}`);
    } else {
      lines.push('Totais (página atual): —');
    }

    if (allTotals) {
      const tag = allTotals.partial ? ' (parcial)' : '';
      lines.push(`Totais (todas páginas)${tag}: ${allTotals.count} notas | ${formatBRL(allTotals.sum)}${allTotals.canceled ? ` | Canceladas: ${allTotals.canceled}` : ''}${allTotals.substituted ? ` | Substituídas: ${allTotals.substituted}` : ''}`);
    } else {
      lines.push('Totais (todas páginas): clique em “Totalizar valores”.');
    }

    el.textContent = lines.join('\n');
  }

  let totalsUpdateTimer = null;
  function scheduleRenderTotals() {
    if (totalsUpdateTimer) clearTimeout(totalsUpdateTimer);
    totalsUpdateTimer = setTimeout(() => {
      try {
        renderTotals();
      } catch {
        // ignore
      }
    }, 250);
  }

  function firstNonEmpty(values) {
    for (const v of values) {
      const s = String(v || '').trim();
      if (s) return s;
    }
    return null;
  }

  function getRetentionInfo(xmlDoc) {
    const idx = indexXmlTextsByLocalNameLower(xmlDoc);

    const tpRetISSQN_values = (idx.get('tpretissqn') || []).map(normalizeEnum);
    const issRetido = tpRetISSQN_values.some(v => v === '2' || v === '3');

    const tpRetPisCofins_values = (idx.get('tpretpiscofins') || []).map(normalizeEnum);
    const pisCofinsRetido = tpRetPisCofins_values.some(v => v === '1');

    const vRetIRRF = sumNumbers(idx.get('vretirrf') || []);
    const vRetCSLL = sumNumbers(idx.get('vretcsll') || []);
    const vRetCP = sumNumbers(idx.get('vretcp') || []);

    const federaisRetidas = pisCofinsRetido || vRetIRRF > 0 || vRetCSLL > 0 || vRetCP > 0;

    function sanitizeCandidateNumber(raw) {
      const digits = String(raw || '').replace(/\D/g, '');
      if (!digits) return null;
      // Evita confundir com CNPJ (14 dígitos) e com identificadores gigantes.
      if (digits.length === 14) return null;
      if (digits.length > 15) return null;
      return digits;
    }

    // Número da NFS-e (NFSe) costuma estar em infNfse/Numero. Já o número do RPS fica em IdentificacaoRps/Numero.
    // Aqui priorizamos o número da NFS-e e ignoramos explicitamente valores vindos de RPS.
    function pickNFSeNumeroFromDom(doc) {
      // 1) Caminhos mais comuns (ABRASF / NFS-e Nacional)
      const directSelectors = [
        'infNfse > Numero',
        'Nfse > infNfse > Numero',
        'CompNfse > Nfse > infNfse > Numero',
        'infNfse IdentificacaoNfse > Numero',
        'IdentificacaoNfse > Numero',
        'NumeroNfse',
        'nNFSe',
        'NumNFSe',
        'NumeroNFSe'
      ];
      for (const sel of directSelectors) {
        const el = doc.querySelector(sel);
        const v = sanitizeCandidateNumber(el?.textContent);
        if (v) return v;
      }

      // 2) Fallback: qualquer <Numero>, mas descartando se estiver dentro de IdentificacaoRps/Rps
      const allNumero = Array.from(doc.getElementsByTagName('*')).filter(e => (e.localName || '').toLowerCase() === 'numero');
      for (const el of allNumero) {
        // sobe na árvore e descarta se algum ancestral indicar RPS
        let p = el;
        let isRps = false;
        while (p && p !== doc) {
          const ln = (p.localName || '').toLowerCase();
          if (ln.includes('rps') || ln.includes('identificacaorps')) { isRps = true; break; }
          p = p.parentNode;
        }
        if (isRps) continue;
        const v = sanitizeCandidateNumber(el.textContent);
        if (v) return v;
      }

      return null;
    }

    // Primeiro tenta pelo DOM (garante NFSe, não RPS). Depois usa índice por tags específicas.
    const nNFSe = pickNFSeNumeroFromDom(xmlDoc) ||
      sanitizeCandidateNumber(firstNonEmpty(idx.get('nnfse') || [])) ||
      sanitizeCandidateNumber(firstNonEmpty(idx.get('numeronfse') || [])) ||
      sanitizeCandidateNumber(firstNonEmpty(idx.get('numnfse') || [])) ||
      null;

    return {
      nNFSe,
      issRetido,
      federaisRetidas,
      tpRetISSQN_values,
      tpRetPisCofins_values,
      vRetIRRF,
      vRetCSLL,
      vRetCP
    };
  }

  // ------------------------ Badge + botão por linha ------------------------
  function ensureBadgeCell(row) {
    const firstCell = row.querySelector('td') || row;
    let wrap = firstCell.querySelector('[data-nfse-retencao-wrap="1"]');
    if (wrap) return wrap;

    wrap = document.createElement('div');
    wrap.setAttribute('data-nfse-retencao-wrap', '1');
    wrap.style.cssText = 'display:inline-flex;gap:6px;align-items:center;margin-left:6px;flex-wrap:wrap;';
    firstCell.appendChild(wrap);
    return wrap;
  }

  function setBadgeKey(row, key, text, kind, title) {
    const wrap = ensureBadgeCell(row);
    let badge = wrap.querySelector(`[data-nfse-retencao-badge="${key}"]`);
    if (!badge) {
      badge = document.createElement('span');
      badge.setAttribute('data-nfse-retencao-badge', String(key));
      badge.style.cssText = [
        'padding:2px 8px',
        'border-radius:999px',
        'border:1px solid currentColor',
        'font-size:12px',
        'white-space:nowrap'
      ].join(';');
      wrap.appendChild(badge);
    }

    badge.textContent = text;
    badge.title = title || '';
    if (kind === 'ok') badge.style.color = '#1b5e20';
    else if (kind === 'warn') badge.style.color = '#e65100';
    else badge.style.color = '#b00020';
  }



function setBadge(row, text, kind, title) {
  return setBadgeKey(row, 'ret', text, kind, title);
}

function setCancelTag(row, text, title) {
  return setBadgeKey(row, 'cancel', text, 'err', title || '');
}

function setSubstTag(row, text, title) {
  setBadge(row, text || 'Substituída', 'info', title || 'Situação: substituída');
}

// ===== Badge do número REAL da NFS-e (via XML) - separado das tags de retenção/cancelamento =====
function ensureNFSeNumHost(row) {
  let host = row.querySelector('.nfse-nfse-num-host');
  if (host) return host;
  host = document.createElement('div');
  host.className = 'nfse-nfse-num-host';
  // Preferir a coluna “Geração” (não mistura com o wrap das retenções)
  const td = row.querySelector('td.td-datahora') || row.cells?.[0] || row;
  td.appendChild(host);
  return host;
}

function setNFSeNumeroBadge(row, numeroNFSe) {
  const n = String(numeroNFSe || '').trim();
  if (!n) return;
  const host = ensureNFSeNumHost(row);
  let badge = host.querySelector('.nfse-nfse-num-badge');
  if (!badge) {
    badge = document.createElement('span');
    badge.className = 'nfse-nfse-num-badge';
    host.appendChild(badge);
  }
  badge.textContent = `NFS-e: ${n}`;
  badge.title = `Número da NFS-e (lido do XML): ${n}`;
}
  function ensureRowXmlButton(row, xmlUrl) {
    const wrap = ensureBadgeCell(row);
    let btn = wrap.querySelector('[data-nfse-retencao-xmlbtn="1"]');
    if (btn) return btn;

    btn = document.createElement('button');
    btn.setAttribute('data-nfse-retencao-xmlbtn', '1');
    btn.type = 'button';
    btn.textContent = 'XML';
    btn.style.cssText = [
      'padding:2px 8px',
      'border-radius:999px',
      'border:1px solid #999',
      'background:#fff',
      'cursor:pointer',
      'font-size:12px',
      'white-space:nowrap'
    ].join(';');

    btn.addEventListener('click', (ev) => {
      ev.preventDefault();
      ev.stopPropagation();
      const statusEl = document.getElementById('nfse-retencao-status');
      downloadXmlFromUrl(xmlUrl, statusEl);
    });

    wrap.appendChild(btn);
    return btn;
  }

  // ------------------------ Pagination (multi-página via FETCH) ------------------------
  function getAllRecebidasPageUrls(doc = document) {
    const pag = doc.querySelector('.paginacao ul.pagination');
    if (!pag) return [location.href];

    // Preferência: usar o link "Última" (ele carrega todos os parâmetros do filtro)
    const last = pag.querySelector('a[title="Última"]');
    if (last) {
      const href = last.getAttribute('href') || '';
      if (href && !href.toLowerCase().startsWith('javascript')) {
        const lastUrl = new URL(href, location.origin);
        const lastPg = Number(lastUrl.searchParams.get('pg') || '1') || 1;
        const urls = [];
        for (let pgNum = 1; pgNum <= lastPg; pgNum++) {
          const u = new URL(lastUrl.toString());
          u.searchParams.set('pg', String(pgNum));
          urls.push(u.toString());
        }
        return urls;
      }
    }

    // Fallback: coleta os links de páginas visíveis
    const links = Array.from(new Set(
      Array.from(pag.querySelectorAll('a[href]'))
        .map(a => a.getAttribute('href') || '')
        .filter(h => h && !h.toLowerCase().startsWith('javascript'))
        .map(h => new URL(h, location.origin).toString())
        .concat([location.href])
    ));

    links.sort((a, b) => getPg(a) - getPg(b));
    return links;
  }


  async function getAllRecebidasPageUrlsRobust(anyPageUrl = location.href) {
    try {
      const u0 = new URL(anyPageUrl, location.origin);
      // Sempre parte da página 1 (independente de onde o usuário esteja)
      u0.searchParams.set('pg', '1');
      const firstUrl = u0.toString();

      const doc1 = await fetchHtmlDoc(firstUrl);
      // tenta pegar pelo link 'Última'
      let lastPg = 1;
      const lastA = doc1.querySelector('.paginacao ul.pagination a[title="Última"]');
      if (lastA) {
        const href = lastA.getAttribute('href') || '';
        if (href && !href.toLowerCase().startsWith('javascript')) {
          const lu = new URL(href, location.origin);
          lastPg = Number(lu.searchParams.get('pg') || '1') || 1;
        }
      }

      // fallback: calcula por "Total de X registros" / tamanho da página 1
      if (!lastPg || lastPg < 1) lastPg = 1;
      if (lastPg === 1) {
        const desc = (doc1.querySelector('.paginacao .descricao')?.textContent || '').replace(/\s+/g, ' ').trim();
        const m = desc.match(/Total\s+de\s+(\d+)\s+registros/i);
        const totalRegs = m ? Number(m[1]) : 0;
        const rows1 = findRows(doc1).length || 0;
        if (totalRegs > 0 && rows1 > 0) {
          lastPg = Math.max(1, Math.ceil(totalRegs / rows1));
        }
      }

      const urls = [];
      for (let pgNum = 1; pgNum <= lastPg; pgNum++) {
        const u = new URL(firstUrl);
        u.searchParams.set('pg', String(pgNum));
        urls.push(u.toString());
      }
      return urls;
    } catch {
      return [location.href];
    }
  }

  function getPg(urlStr) {
    try {
      const u = new URL(urlStr);
      return Number(u.searchParams.get('pg') || '1') || 1;
    } catch {
      return 1;
    }
  }

  async function fetchHtmlDoc(url) {
    const resp = await fetch(url, { credentials: 'include' });
    if (!resp.ok) throw new Error(`Falha ao carregar página (HTTP ${resp.status})`);
    const text = await resp.text();

    // Se vier HTML de login/erro, isso costuma indicar sessão expirada
    if (/<!doctype\s+html/i.test(text) && /Login|Entrar|Acesso/i.test(text) && /EmissorNacional/i.test(text) === false) {
      // heurística leve — não bloqueia sempre
    }

    return new DOMParser().parseFromString(text, 'text/html');
  }


function pageLooksCanceled(doc) {
  try {
    // Detector mais confiável para evitar falso positivo (ex.: botões "Cancelar", "Rejeitar", etc.)
    const bodyText = (doc.body && doc.body.innerText ? doc.body.innerText : '');

    // 1) "Situação" explícita (estrutura)
    // Procura por trechos do tipo "Situação ... Cancelada"
    const norm = bodyText.toLowerCase().replace(/\s+/g, ' ');
    if (/situaç[aã]o[^\n]{0,120}cancelad[ao]/i.test(norm)) return true;

    // 2) Seção de eventos (quando existir)
    // "Evento" perto de "Cancelamento"
    if (/evento[^\n]{0,200}cancelamento/i.test(norm)) return true;

    // 3) Frases comuns no detalhe
    if (/nfs-?e[^\n]{0,40}cancelad[ao]/i.test(norm)) return true;

    // 4) Alguns detalhes exibem um badge/label com title específico (mas NÃO qualquer "cancel*")
    const titles = Array.from(doc.querySelectorAll('[title], [data-original-title]'))
      .map(el => (el.getAttribute('title') || el.getAttribute('data-original-title') || ''))
      .join(' ')
      .toLowerCase();

    // Aceita apenas títulos que descrevem situação cancelada, não ações
    if (titles.includes('nfs-e cancelada') || titles.includes('nota cancelada') || titles.includes('situação: cancelada')) return true;

  } catch {}
  return false;
}


async function checkCanceladasViaVisualizacao(statusEl) {
  if (STATE.running) return;
  STATE.running = true;
  STATE.stopRequested = false;

  try {
    ensureUI();

    if (!looksLikeNotasPage()) {
            setStatus(statusEl, `Acesse “${notasLabel()}” e clique em “Checar canceladas (visualização)”.`);
      return;
    }

    // Mapa da página atual para aplicar a tag imediatamente (sem esperar o usuário trocar de página)
    const currentRows = findRows(document);
    const currentRowByKey = new Map();
    for (const row of currentRows) {
      const xmlUrl = extractXmlUrlFromRow(row);
      if (!xmlUrl) continue;
      const k = extractNotaKeyFromUrl(xmlUrl);
      if (k) currentRowByKey.set(k, row);
    }

    // 1) Coleta TODAS as páginas (independente da página atual) — modo rápido
    const pageUrls = await getAllRecebidasPageUrlsRobust(location.href);
    setStatus(statusEl, `Coletando notas (páginas: ${pageUrls.length})...`);

    // 2) Extrai todos os links de visualização de TODAS as páginas (rápido)
    const visUrls = new Set();
    let pagesDone = 0;

    await mapLimit(pageUrls, 2, async (purl) => {
      if (STATE.stopRequested) return;
      const doc = await fetchHtmlDoc(purl);
      await delay(80);
      const rows = findRows(doc);
      for (const row of rows) {
        const visUrl = extractVisualizarUrlFromRow(row);
        if (!visUrl) continue;
        visUrls.add(visUrl);
      }
      pagesDone++;
      if (pagesDone % 2 === 0) {
        setStatus(statusEl, `Coletando visualizações: ${pagesDone}/${pageUrls.length} páginas...`);
      }
    });

    const visList = Array.from(visUrls);
    if (!visList.length) {
      setStatus(statusEl, 'Nenhuma URL de visualização encontrada nas páginas.');
      return;
    }

    // 3) Checa as visualizações em paralelo (mais rápido) e marca canceladas
    let checked = 0;
    let found = 0;

    setStatus(statusEl, `Verificando cancelamento: 0/${visList.length}...`);

    await mapLimit(visList, 3, async (visUrl) => {
      if (STATE.stopRequested) return;

      const key = extractNotaKeyFromUrl(visUrl);
      if (!key) return;

      checked++;
      if (CANCELED_KEYS.has(key)) return;

      try {
        const vdoc = await fetchHtmlDoc(visUrl);
        await delay(80);
        const canceled = pageLooksCanceled(vdoc);
        if (canceled) {
          CANCELED_KEYS.add(key);
          noteCacheSetCanceled(key);
          saveCanceledKeysSoon();
          found++;

          const curRow = currentRowByKey.get(key);
          if (curRow) setCancelTag(curRow, 'Cancelada', 'Confirmada na visualização (evento/situação)');
        }
      } catch {}

      if (checked % 15 === 0) {
        setStatus(statusEl, `Checadas: ${checked}/${visList.length} | Canceladas: ${found}` + (STATE.stopRequested ? ' | Parando...' : ''));
      }
    });

    scheduleRenderTotals();

    if (STATE.stopRequested) setStatus(statusEl, `Parado. Checadas: ${checked}/${visList.length} | Canceladas: ${found}`);
    else setStatus(statusEl, `Finalizado. Checadas: ${checked}/${visList.length} | Canceladas: ${found}`);

  } catch (e) {
    console.error(e);
    setStatus(statusEl, 'Erro ao checar canceladas (visualização). Veja o console.');
  } finally {
    STATE.running = false;
  }
}

async function discoverRecebidasPagesProgressive(anyPageUrl, hardCap = 500) {
  try {
    const u = new URL(anyPageUrl, location.origin);
    u.searchParams.set('pg', '1');
    const base = u.toString();

    const urls = [];
    let lastFirstKey = null;

    for (let pg = 1; pg <= hardCap; pg++) {
      const pu = new URL(base);
      pu.searchParams.set('pg', String(pg));
      const doc = await fetchHtmlDoc(pu.toString());
      const rows = findRows(doc);
      if (!rows || rows.length === 0) break;

      // evita loop de redirect/repetição: compara a 1ª chave/URL de XML da página
      const first = rows[0];
      const xmlUrl = extractXmlUrlFromRow(first);
      const fk = xmlUrl ? extractNotaKeyFromUrl(xmlUrl) : null;
      if (fk && fk === lastFirstKey) break;
      lastFirstKey = fk || lastFirstKey;

      urls.push(pu.toString());
    }
    return urls.length ? urls : [anyPageUrl];
  } catch {
    return [anyPageUrl];
  }
}


  async function collectXmlUrlsFromAllPages(statusEl) {
    const pageUrls = await getAllRecebidasPageUrlsRobust(location.href);
    const totalPages = pageUrls.length;

    const xmlUrls = [];

    let totalsCount = 0;
    let totalsSum = 0;
    let totalsMissing = 0;
    let totalsCanceled = 0;

    // Mapa para atualizar badges na página atual (quando der match)
    const currentRows = findRows(document);
    const currentRowByXmlUrl = new Map();
    for (const row of currentRows) {
      const url = extractXmlUrlFromRow(row);
      if (url) currentRowByXmlUrl.set(url, row);
    }

    // Para garantir que pegamos exatamente o HTML renderizado com filtro,
    // vamos buscar todas as páginas via fetch (inclui a página 1).
    for (let i = 0; i < totalPages; i++) {
      if (STATE.stopRequested) break;

      const pageUrl = pageUrls[i];
      setStatus(statusEl, `Lendo páginas: ${i + 1}/${totalPages}...`);

      const doc = await fetchHtmlDoc(pageUrl);
      const rows = findRows(doc);

      const pageTotals = calcTotalsFromRows(rows);
      totalsCount += pageTotals.count;
      totalsSum += pageTotals.sum;
      totalsMissing += pageTotals.missing;
      totalsCanceled += (pageTotals.canceled || 0);

      for (const row of rows) {
        const xmlUrl = extractXmlUrlFromRow(row);
        if (!xmlUrl) continue;
        if (isExcludedRow(row)) continue; // não inclui canceladas/substituídas no lote
        xmlUrls.push(xmlUrl);
      }
    }

    // Dedup
    const unique = Array.from(new Set(xmlUrls));

    // Garante botão de download na linha da página atual
    for (const [u, row] of currentRowByXmlUrl.entries()) {
      ensureRowXmlButton(row, u);
    }

    return { pageUrls, xmlUrls: unique, currentRowByXmlUrl, totals: { count: totalsCount, sum: totalsSum, missing: totalsMissing, canceled: totalsCanceled } };
  }

  // ------------------------ Concurrency helper ------------------------
  async function mapLimit(items, limit, fn) {
    const executing = new Set();
    const results = [];

    for (const item of items) {
      if (STATE.stopRequested) break;

      const p = Promise.resolve().then(() => fn(item));
      results.push(p);
      executing.add(p);

      const cleanup = () => executing.delete(p);
      p.then(cleanup).catch(cleanup);

      if (executing.size >= limit) {
        await Promise.race(executing);
      }
    }

    return Promise.allSettled(results);
  }

  // ------------------------ Download helpers ------------------------
  async function fetchXmlText(xmlUrl) {
    const resp = await fetch(xmlUrl, { credentials: 'include' });
    if (!resp.ok) throw new Error(`Falha ao baixar XML (HTTP ${resp.status})`);
    const text = await resp.text();

    // Se o endpoint retornar HTML (sessão expirada / erro), não dá pra parsear.
    if (/<!doctype\s+html/i.test(text) || /<html[\s>]/i.test(text)) {
      throw new Error('O download retornou HTML (possível sessão expirada ou bloqueio). Faça login novamente e tente.');
    }
    return text;
  }

  function downloadBlob(blob, filename) {
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  }

  function downloadTextAsFile(text, filename, mime = 'application/xml;charset=utf-8') {
    downloadBlob(new Blob([text], { type: mime }), filename);
  }

  function suggestXmlFilenameFromInfo(xmlUrl, info) {
    const id = extractIdFromXmlUrl(xmlUrl);
    const n = info && info.nNFSe ? String(info.nNFSe).trim() : '';
    if (n) return `nfse-recebida-${n}.xml`;
    if (id) return `nfse-recebida-${id}.xml`;
    return `nfse-recebida-${new Date().toISOString().replace(/[:.]/g, '-')}.xml`;
  }

  async function downloadXmlFromUrl(xmlUrl, statusEl) {
    try {
      setStatus(statusEl, 'Baixando XML...');
      const xmlText = await fetchXmlText(xmlUrl);
      let info;
      try {
        info = getRetentionInfo(parseXml(xmlText));
      } catch {
        info = null;
      }
      const filename = suggestXmlFilenameFromInfo(xmlUrl, info);
      downloadTextAsFile(xmlText, filename);
      setStatus(statusEl, `Download iniciado: ${filename}`);
    } catch (e) {
      setStatus(statusEl, 'Falha ao baixar XML: ' + String(e && e.message ? e.message : e));
    }
  }

  async function downloadXmlSelecionada(statusEl) {
    ensureUI();

    if (!looksLikeNotasPage()) {
            setStatus(statusEl, `Acesse “${notasLabel()}”, selecione uma nota e clique em “Baixar XML da seleção”.`);
      return;
    }

    const row = STATE.selectedRow;
    if (!row) {
      setStatus(statusEl, 'Clique em uma nota da tabela para selecionar e então clique em “Baixar XML da seleção”.');
      return;
    }

    const xmlUrl = extractXmlUrlFromRow(row);
    if (!xmlUrl) {
      setStatus(statusEl, 'Não encontrei a URL do “Download XML” nessa linha.');
      return;
    }

    await downloadXmlFromUrl(xmlUrl, statusEl);
  }

  // ------------------------ Download DANFS-e (PDF) - Canceladas ------------------------
  function buildDanfseUrlFromId(id) {
    return `${location.origin}/EmissorNacional/Notas/Download/DANFSe/${encodeURIComponent(String(id))}`;
  }

  function collectCanceledIdsFromCurrentTable() {
    const out = new Set();
    document.querySelectorAll('tr[data-chave]').forEach(row => {
      if (!isExcludedRow(row)) return;
      const xmlUrl = extractXmlUrlFromRow(row);
      const id = xmlUrl ? extractNotaKeyFromUrl(xmlUrl) : null;
      if (id) out.add(String(id));
    });
    return out;
  }

  async function downloadCanceledPdfs(statusEl) {
    ensureUI();

    if (!looksLikeNotasPage()) {
            setStatus(statusEl, `Acesse “${notasLabel()}” para baixar os PDFs das canceladas.`);
      return;
    }

    // Carrega cache persistido (mesma base usada para canceladas)
    loadCanceledKeys();
  loadSubstitutedKeys();
    await loadCanceledKeysFromStorage();
  loadSubstitutedKeysFromStorage();
    await loadNoteCacheFromStorage();

    // Junta todas as fontes: cache + o que a página atual já mostra
    const ids = new Set(Array.from(CANCELED_KEYS));
    for (const id of collectCanceledIdsFromCurrentTable()) ids.add(id);
    for (const [k, v] of NOTE_CACHE.entries()) {
      if (v && v.cancel) ids.add(String(k));
    }

    // IDs canceladas detectadas (de todas as fontes)
    const canceledSet = new Set(Array.from(ids).filter(Boolean));

    if (!canceledSet.size) {
      setStatus(statusEl, 'Nenhuma nota cancelada identificada no cache. Rode “Checar canceladas (visualização)” primeiro.');
      return;
    }

    // Para não contar a mais: limita o download SOMENTE às notas do período/filtro atual
    // (varre todas as páginas do período atual e cruza com o set de canceladas)
    setStatus(statusEl, 'Coletando IDs do período atual (todas as páginas)...');
    const periodIds = new Set();
    try {
      const pageUrls = await getAllRecebidasPageUrlsRobust(location.href);
      for (let p = 0; p < pageUrls.length; p++) {
        if (STATE.stopRequested) break;
        const pageUrl = pageUrls[p];
        const doc = await fetchHtmlDoc(pageUrl);
        const rows = findRows(doc);
        for (const row of rows) {
          const aXml = row.querySelector('a[href*="/Notas/Download/NFSe/"]') || row.querySelector('a[href*="/Notas/Visualizar/Index/"]');
          if (!aXml) continue;
          const href = aXml.getAttribute('href') || '';
          const id = new URL(href, location.origin).pathname.split('/').pop();
          if (id) periodIds.add(String(id));
        }
        setStatus(statusEl, `Coletando IDs do período: ${p + 1}/${pageUrls.length}`);
        await delay(60);
      }
    } catch (e) {
      // fallback: se falhar, usa só o que tem na página atual (melhor do que quebrar)
      for (const row of findRows(document)) {
        const aXml = row.querySelector('a[href*="/Notas/Download/NFSe/"]') || row.querySelector('a[href*="/Notas/Visualizar/Index/"]');
        if (!aXml) continue;
        const id = aXml.href.split('/').pop();
        if (id) periodIds.add(String(id));
      }
    }

    const list = Array.from(periodIds).filter(id => canceledSet.has(String(id)));
    if (!list.length) {
      setStatus(statusEl, 'Nenhuma nota cancelada encontrada dentro do período atual.');
      return;
    }
STATE.stopRequested = false;
    STATE.running = true;

    // Empacota em ZIP (store) para não abrir vários downloads
    const zip = new SimpleZip();
    setStatus(statusEl, `Baixando e empacotando ${list.length} PDF(s) (DANFS-e) em ZIP...`);

    let ok = 0;
    for (let i = 0; i < list.length; i++) {
      if (STATE.stopRequested) break;

      const id = list[i];
      const url = buildDanfseUrlFromId(id);

      try {
        const resp = await fetch(url, { credentials: 'include' });
        if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
        const ab = await resp.arrayBuffer();
        const bytes = new Uint8Array(ab);
        zip.addFile(`DANFSe_cancelada_${id}.pdf`, bytes);
        ok++;
      } catch (e) {
        // ignora falhas individuais, segue
      }

      setStatus(statusEl, `PDFs (canceladas): ${i + 1}/${list.length} (ok: ${ok})`);
      await delay(180); // leve, para não travar o portal
    }

    const blob = zip.toBlob();
    downloadBlob(blob, `danfse_canceladas_${new Date().toISOString().slice(0,10)}.zip`);

    STATE.running = false;
    STATE.stopRequested = false;
    setStatus(statusEl, `✅ ZIP gerado com ${ok}/${list.length} PDF(s).`);
  }


  // ------------------------ ZIP builder (store, sem compressão) ------------------------
  // Implementação simples de ZIP (método 0 - store), suficiente para empacotar XMLs.

  function makeCrcTable() {
    const table = new Uint32Array(256);
    for (let n = 0; n < 256; n++) {
      let c = n;
      for (let k = 0; k < 8; k++) {
        c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1);
      }
      table[n] = c >>> 0;
    }
    return table;
  }

  const CRC_TABLE = makeCrcTable();

  function crc32(buf) {
    let c = 0xFFFFFFFF;
    for (let i = 0; i < buf.length; i++) {
      c = CRC_TABLE[(c ^ buf[i]) & 0xFF] ^ (c >>> 8);
    }
    return (c ^ 0xFFFFFFFF) >>> 0;
  }

  function u16(n) {
    const b = new Uint8Array(2);
    b[0] = n & 0xFF;
    b[1] = (n >>> 8) & 0xFF;
    return b;
  }

  function u32(n) {
    const b = new Uint8Array(4);
    b[0] = n & 0xFF;
    b[1] = (n >>> 8) & 0xFF;
    b[2] = (n >>> 16) & 0xFF;
    b[3] = (n >>> 24) & 0xFF;
    return b;
  }

  function concatChunks(chunks) {
    let total = 0;
    for (const c of chunks) total += c.length;
    const out = new Uint8Array(total);
    let offset = 0;
    for (const c of chunks) {
      out.set(c, offset);
      offset += c.length;
    }
    return out;
  }

  class SimpleZip {
    constructor() {
      this.files = []; // {nameBytes, dataBytes, crc, offset, size}
      this.encoder = new TextEncoder();
      this.usedNames = new Set();
    }

    addFile(name, dataBytes) {
      const safeName = this.makeUniqueName(name);
      const nameBytes = this.encoder.encode(safeName);
      const crc = crc32(dataBytes);
      this.files.push({ name: safeName, nameBytes, dataBytes, crc, offset: 0, size: dataBytes.length });
    }

    makeUniqueName(name) {
      const base = String(name || 'arquivo');
      if (!this.usedNames.has(base)) {
        this.usedNames.add(base);
        return base;
      }
      // evita duplicar nomes
      const dot = base.lastIndexOf('.');
      const stem = dot > 0 ? base.slice(0, dot) : base;
      const ext = dot > 0 ? base.slice(dot) : '';
      let i = 2;
      while (this.usedNames.has(`${stem}-${i}${ext}`)) i++;
      const out = `${stem}-${i}${ext}`;
      this.usedNames.add(out);
      return out;
    }

    toBlob() {
      const chunks = [];
      const central = [];
      let offset = 0;

      // Local file headers + data
      for (const f of this.files) {
        f.offset = offset;

        const localHeader = concatChunks([
          u32(0x04034b50), // local file header signature
          u16(20), // version needed
          u16(0), // flags
          u16(0), // compression 0=store
          u16(0), // mod time
          u16(0), // mod date
          u32(f.crc),
          u32(f.size),
          u32(f.size),
          u16(f.nameBytes.length),
          u16(0) // extra len
        ]);

        chunks.push(localHeader, f.nameBytes, f.dataBytes);
        offset += localHeader.length + f.nameBytes.length + f.dataBytes.length;
      }

      const centralStart = offset;

      // Central directory
      for (const f of this.files) {
        const centralHeader = concatChunks([
          u32(0x02014b50), // central dir signature
          u16(20), // version made by
          u16(20), // version needed
          u16(0), // flags
          u16(0), // compression
          u16(0), // mod time
          u16(0), // mod date
          u32(f.crc),
          u32(f.size),
          u32(f.size),
          u16(f.nameBytes.length),
          u16(0), // extra len
          u16(0), // comment len
          u16(0), // disk start
          u16(0), // internal attrs
          u32(0), // external attrs
          u32(f.offset),
        ]);
        central.push(centralHeader, f.nameBytes);
        offset += centralHeader.length + f.nameBytes.length;
      }

      const centralBytes = concatChunks(central);
      chunks.push(centralBytes);

      const centralSize = centralBytes.length;

      // End of central directory
      const eocd = concatChunks([
        u32(0x06054b50),
        u16(0),
        u16(0),
        u16(this.files.length),
        u16(this.files.length),
        u32(centralSize),
        u32(centralStart),
        u16(0)
      ]);
      chunks.push(eocd);

      const out = concatChunks(chunks);
      return new Blob([out], { type: 'application/zip' });
    }
  }

  // ------------------------ Core actions ------------------------

  function buildPartsFromInfo(info) {
    const parts = [];
    if (info.issRetido) parts.push('ISS retido');
    if (info.federaisRetidas) {
      const sub = [];
      if ((info.tpRetPisCofins_values || []).some(v => v === '1')) sub.push('PIS/COFINS');
      if (info.vRetIRRF > 0) sub.push(`IRRF ${info.vRetIRRF.toFixed(2)}`);
      if (info.vRetCSLL > 0) sub.push(`CSLL ${info.vRetCSLL.toFixed(2)}`);
      if (info.vRetCP > 0) sub.push(`CP ${info.vRetCP.toFixed(2)}`);
      parts.push('Fed: ' + (sub.length ? sub.join(', ') : 'sim'));
    }
    return parts;
  }

  async function runPage(statusEl) {
    if (STATE.running) return;
    STATE.running = true;
    STATE.stopRequested = false;

    try {
      ensureUI();

      if (!looksLikeNotasPage()) {
                setStatus(statusEl, `Acesse “${notasLabel()}” e clique em “Analisar página”.`);
        return;
      }

      const rows = findRows(document);
      setStatus(statusEl, `Encontradas ${rows.length} linhas. Checando...`);

      let ok = 0, erro = 0, semXml = 0, canceladas = 0, substituidas = 0;

      await mapLimit(rows, 3, async (row) => {
        const xmlUrl = extractXmlUrlFromRow(row);
        if (!xmlUrl) {
          semXml++;
          setBadge(row, 'Sem XML', 'err', 'Não encontrei o link “Download XML” na linha.');
          return;
        }

        ensureRowXmlButton(row, xmlUrl);

        // Se for cancelada/substituída (pela Situação ou cache), marca e pula XML
        if (isCanceledRow(row)) {
          canceladas++;
          setCancelTag(row, 'Cancelada', 'Nota cancelada (não entra no total / não baixa XML)');
          setStatus(statusEl, `Processadas: ${ok + erro + semXml + canceladas + substituidas}/${rows.length} | OK: ${ok} | Erros: ${erro} | Sem XML: ${semXml} | Canceladas: ${canceladas} | Substituídas: ${substituidas}` + (STATE.stopRequested ? ' | Parando...' : ''));
          return;
        }
        if (isSubstitutedRow(row)) {
          substituidas++;
          setSubstTag(row, 'Substituída', 'Nota substituída (desconsiderada nos totalizadores / não baixa XML)');
          setStatus(statusEl, `Processadas: ${ok + erro + semXml + canceladas + substituidas}/${rows.length} | OK: ${ok} | Erros: ${erro} | Sem XML: ${semXml} | Canceladas: ${canceladas} | Substituídas: ${substituidas}` + (STATE.stopRequested ? ' | Parando...' : ''));
          return;
        }

        try {
          const xmlText = await fetchXmlText(xmlUrl);
          const info = getRetentionInfo(parseXml(xmlText));

          // Número real da NFS-e (via XML)
          if (info && info.nNFSe) {
            setNFSeNumeroBadge(row, info.nNFSe);
          }

          const parts = buildPartsFromInfo(info);
          const hasRet = parts.length > 0;

          const tooltip = `XML: ${xmlUrl}\n` +
            `tpRetISSQN: ${(info.tpRetISSQN_values || []).join(',') || '(vazio)'}\n` +
            `tpRetPisCofins: ${(info.tpRetPisCofins_values || []).join(',') || '(vazio)'}\n` +
            `vRetIRRF: ${info.vRetIRRF}\n` +
            `vRetCSLL: ${info.vRetCSLL}\n` +
            `vRetCP: ${info.vRetCP}`;

          const badgeText = !hasRet ? 'Sem retenção' : parts.join(' | ');
          const kind = !hasRet ? 'ok' : 'warn';

          // persiste resultado para reaplicar ao trocar de página
          RESULTS_BY_XML_URL.set(xmlUrl, { ...info, xmlUrl, ok: true, badgeText, kind, title: tooltip });
          // também persiste por NOTA (para manter tags entre páginas de forma infalível)
          const nk2 = extractNotaKeyFromUrl(xmlUrl);
          const sk2 = extractStableRowKeyFromRow(row, xmlUrl) || nk2;
          if (sk2) {
            noteCacheSetRet(sk2, badgeText, kind, tooltip);
            retByIdSet(sk2, badgeText, kind, tooltip);
            if (info && info.nNFSe) noteCacheSetNumeroNFSe(sk2, info.nNFSe);
          }
          if (nk2 && nk2 !== sk2) {
            noteCacheSetRet(nk2, badgeText, kind, tooltip);
            retByIdSet(nk2, badgeText, kind, tooltip);
            if (info && info.nNFSe) noteCacheSetNumeroNFSe(nk2, info.nNFSe);
          }
          saveResultsSoon();

          setBadge(row, badgeText, kind, tooltip);

          ok++;
        } catch (e) {
          erro++;
          const msg = (e && e.message) ? e.message : String(e);
          setBadge(row, 'Erro', 'err', msg);
          RESULTS_BY_XML_URL.set(xmlUrl, { xmlUrl, ok: false, error: msg });
        saveResultsSoon();
        } finally {
          setStatus(statusEl, `Processadas: ${ok + erro + semXml + canceladas + substituidas}/${rows.length} | OK: ${ok} | Erros: ${erro} | Sem XML: ${semXml} | Canceladas: ${canceladas} | Substituídas: ${substituidas}` + (STATE.stopRequested ? ' | Parando...' : ''));
        }
      });

      if (STATE.stopRequested) {
        setStatus(statusEl, 'Parado.');
      } else {
        setStatus(statusEl, `Finalizado. OK: ${ok} | Erros: ${erro} | Sem XML: ${semXml} | Canceladas: ${canceladas}`);
      }
    } finally {
      // garante persistência antes do usuário trocar de página
      saveRetByIdNow();
      saveNoteCacheNow();
      saveResultsNow();
      STATE.running = false;
    }
  }

  async function runAllPages(statusEl) {
    if (STATE.running) return;
    STATE.running = true;
    STATE.stopRequested = false;

    try {
      ensureUI();

      if (!looksLikeNotasPage()) {
                setStatus(statusEl, `Acesse “${notasLabel()}” e clique em “Analisar período”.`);
        return;
      }

      setStatus(statusEl, 'Coletando XMLs de todas as páginas...');
      const { pageUrls, xmlUrls, currentRowByXmlUrl, totals } = await collectXmlUrlsFromAllPages(statusEl);

      if (totals && totals.count) {
        STATE.allTotals = { ...totals, pages: pageUrls.length, partial: false, at: Date.now() };
        renderTotals();
      }

      if (!xmlUrls.length) {
        setStatus(statusEl, 'Não encontrei nenhum link de XML nas páginas.');
        return;
      }

      setStatus(statusEl, `Encontrados ${xmlUrls.length} XMLs em ${pageUrls.length} páginas. Checando...`);

      let ok = 0, erro = 0;
      let retidas = 0;

      await mapLimit(xmlUrls, 4, async (xmlUrl) => {
        try {
          const xmlText = await fetchXmlText(xmlUrl);
          const info = getRetentionInfo(parseXml(xmlText));

          // Número REAL da NFS-e (via XML) — precisa funcionar também no “Analisar período”
          const nk_num = extractNotaKeyFromUrl(xmlUrl);
          if (info && info.nNFSe && nk_num) {
            noteCacheSetNumeroNFSe(nk_num, info.nNFSe);
          }
          const parts = buildPartsFromInfo(info);
          const hasRet = parts.length > 0;
          if (hasRet) retidas++;

          // Tooltip + badge (persistidos) — necessário para manter as tags ao trocar de página
          const tooltip = `XML: ${xmlUrl}\n` +
            `tpRetISSQN: ${(info.tpRetISSQN_values || []).join(',') || '(vazio)'}\n` +
            `tpRetPisCofins: ${(info.tpRetPisCofins_values || []).join(',') || '(vazio)'}\n` +
            `vRetIRRF: ${info.vRetIRRF}\n` +
            `vRetCSLL: ${info.vRetCSLL}\n` +
            `vRetCP: ${info.vRetCP}`;

          const badgeText = !hasRet ? 'Sem retenção' : parts.join(' | ');
          const kind = !hasRet ? 'ok' : 'warn';

          // Salva por URL e (principal) por ID da nota — mesma lógica “infalível” usada nas canceladas
          RESULTS_BY_XML_URL.set(xmlUrl, { ...info, xmlUrl, ok: true, badgeText, kind, title: tooltip });
          const nk = extractNotaKeyFromUrl(xmlUrl);
          if (nk) {
            noteCacheSetRet(nk, badgeText, kind, tooltip);
            retByIdSet(nk, badgeText, kind, tooltip);
          }
          saveResultsSoon();

          // Atualiza badge na página atual se este xmlUrl estiver nela
          const row = currentRowByXmlUrl.get(xmlUrl);
          if (row) {
            setBadge(row, badgeText, kind, tooltip);
            if (info && info.nNFSe) setNFSeNumeroBadge(row, info.nNFSe);
          }

          ok++;
        } catch (e) {
          erro++;
          const msg = (e && e.message) ? e.message : String(e);
          RESULTS_BY_XML_URL.set(xmlUrl, { xmlUrl, ok: false, error: msg });
        saveResultsSoon();
        } finally {
          setStatus(statusEl, `Checados: ${ok + erro}/${xmlUrls.length} | OK: ${ok} | Erros: ${erro} | Com retenção: ${retidas}` + (STATE.stopRequested ? ' | Parando...' : ''));
        }
      });

      if (STATE.stopRequested) {
        setStatus(statusEl, `Parado. Checados: ${ok + erro}/${xmlUrls.length} | OK: ${ok} | Erros: ${erro} | Com retenção: ${retidas}`);
      } else {
        setStatus(statusEl, `Finalizado (todas páginas). Total: ${xmlUrls.length} | OK: ${ok} | Erros: ${erro} | Com retenção: ${retidas}`);
      }

      STATE.lastSummary = { total: xmlUrls.length, ok, erro, retidas, pages: pageUrls.length };
    } finally {
      // garante persistência antes do usuário trocar de página
      saveRetByIdNow();
      saveNoteCacheNow();
      saveResultsNow();
      STATE.running = false;
    }
  }

  async function totalizeAllPages(statusEl) {
    if (STATE.running) return;
    STATE.running = true;
    STATE.stopRequested = false;

    try {
      ensureUI();

      if (!looksLikeNotasPage()) {
                setStatus(statusEl, `Acesse “${notasLabel()}” e clique em “Totalizar valores”.`);
        return;
      }

      const pageUrls = await getAllRecebidasPageUrlsRobust(location.href);
      if (!pageUrls || !pageUrls.length) {
        setStatus(statusEl, 'Não encontrei paginação/URLs para totalizar.');
        return;
      }

      let totalSum = 0;
      let totalCount = 0;
      let totalMissing = 0;

      for (let i = 0; i < pageUrls.length; i++) {
        if (STATE.stopRequested) break;
        setStatus(statusEl, `Totalizando valores: página ${i + 1}/${pageUrls.length}...`);
        const doc = await fetchHtmlDoc(pageUrls[i]);
        const t = calcTotalsFromDocument(doc);
        totalSum += t.sum;
        totalCount += t.count;
        totalMissing += t.missing;
      }

      STATE.allTotals = {
        count: totalCount,
        sum: totalSum,
        missing: totalMissing,
        pages: pageUrls.length,
        partial: !!STATE.stopRequested,
        at: Date.now()
      };

      renderTotals();

      if (STATE.stopRequested) {
        setStatus(statusEl, `Total parcial: ${totalCount} notas | ${formatBRL(totalSum)} (páginas: ${pageUrls.length})`);
      } else {
        setStatus(statusEl, `Total geral: ${totalCount} notas | ${formatBRL(totalSum)} (páginas: ${pageUrls.length})`);
      }
    } catch (e) {
      setStatus(statusEl, 'Falha ao totalizar: ' + String(e && e.message ? e.message : e));
    } finally {
      STATE.running = false;
    }
  }

  function buildZipFilename() {
    const di = (document.querySelector('#datainicio') && document.querySelector('#datainicio').value) ? document.querySelector('#datainicio').value : '';
    const df = (document.querySelector('#datafim') && document.querySelector('#datafim').value) ? document.querySelector('#datafim').value : '';
    const safeDi = di ? di.replace(/\//g, '-') : '';
    const safeDf = df ? df.replace(/\//g, '-') : '';
    const stamp = new Date().toISOString().slice(0, 19).replace(/[:T]/g, '-');
    const range = (safeDi && safeDf) ? `${safeDi}_a_${safeDf}` : 'periodo';
    return `NFSe_Recebidas_XMLs_${range}_${stamp}${STATE.stopRequested ? '_parcial' : ''}.zip`;
  }

  async function downloadAllXmlZip(statusEl) {
    if (STATE.running) return;
    STATE.running = true;
    STATE.stopRequested = false;

    try {
      ensureUI();

      if (!looksLikeNotasPage()) {
                setStatus(statusEl, `Acesse “${notasLabel()}” e clique em “Exportar XMLs”.`);
        return;
      }

      setStatus(statusEl, 'Coletando XMLs de todas as páginas...');
      const { pageUrls, xmlUrls, totals } = await collectXmlUrlsFromAllPages(statusEl);

      if (totals && totals.count) {
        STATE.allTotals = { ...totals, pages: pageUrls.length, partial: false, at: Date.now() };
        renderTotals();
      }

      if (!xmlUrls.length) {
        setStatus(statusEl, 'Não encontrei nenhum link de XML nas páginas.');
        return;
      }

      setStatus(statusEl, `Encontrados ${xmlUrls.length} XMLs em ${pageUrls.length} páginas. Baixando e preparando arquivos...`);

      const zip = new SimpleZip();
      const encoder = new TextEncoder();

      let ok = 0, erro = 0;
      const errors = [];

      await mapLimit(xmlUrls, 4, async (xmlUrl) => {
        try {
          const xmlText = await fetchXmlText(xmlUrl);

          // Opcional: tenta pegar nNFSe só para nomear melhor o arquivo.
          let info = null;
          try {
            info = getRetentionInfo(parseXml(xmlText));
            RESULTS_BY_XML_URL.set(xmlUrl, { ...info, xmlUrl, ok: true });
        saveResultsSoon();
          } catch {
            // Se não der parse, ainda assim adiciona o XML no ZIP com nome baseado na chave.
            RESULTS_BY_XML_URL.set(xmlUrl, { xmlUrl, ok: true });
        saveResultsSoon();
          }

          const filename = suggestXmlFilenameFromInfo(xmlUrl, info);
          zip.addFile(filename, encoder.encode(xmlText));
          ok++;
        } catch (e) {
          erro++;
          const msg = (e && e.message) ? e.message : String(e);
          errors.push(`${xmlUrl} -> ${msg}`);
          RESULTS_BY_XML_URL.set(xmlUrl, { xmlUrl, ok: false, error: msg });
        saveResultsSoon();
        } finally {
          setStatus(statusEl, `Baixados: ${ok + erro}/${xmlUrls.length} | OK: ${ok} | Erros: ${erro}` + (STATE.stopRequested ? ' | Parando...' : ''));
        }
      });

      if (totals && totals.count) {
        STATE.allTotals = { ...totals, pages: pageUrls.length, partial: !!STATE.stopRequested, at: Date.now() };
        renderTotals();
      }

      // Relatório
      const reportLines = [];
      reportLines.push('Relatório de exportação — NFS-e Recebidas');
      reportLines.push(`Gerado em: ${new Date().toISOString()}`);
      reportLines.push(`Paginas varridas: ${pageUrls.length}`);
      reportLines.push(`XMLs encontrados: ${xmlUrls.length}`);
      reportLines.push(`XMLs exportados: ${ok}`);
      reportLines.push(`Erros: ${erro}`);
      if (totals && totals.count) {
        reportLines.push(`Total de notas (linhas): ${totals.count}`);
        reportLines.push(`Valor total das notas (Preço Serviço): ${formatBRL(totals.sum)}`);
        if (totals.missing) reportLines.push(`Linhas sem valor lido: ${totals.missing}`);
      }
      if (STATE.stopRequested) reportLines.push('Status: PARCIAL (usuario clicou em Parar)');
      reportLines.push('');
      if (errors.length) {
        reportLines.push('--- ERROS ---');
        reportLines.push(...errors);
      }

      zip.addFile('relatorio.txt', encoder.encode(reportLines.join('\n')));

      const blob = zip.toBlob();
      const zipName = buildZipFilename();
      downloadBlob(blob, zipName);

      if (STATE.stopRequested) {
        setStatus(statusEl, `Exportação parcial concluída. Download iniciado. OK: ${ok} | Erros: ${erro}`);
      } else {
        setStatus(statusEl, `Exportação concluída. Download iniciado. OK: ${ok} | Erros: ${erro}`);
      }
    } finally {
      STATE.running = false;
    }
  }

  // ------------------------ Boot + keep alive ------------------------
  function boot() {
    loadCanceledKeys();
  loadSubstitutedKeys();
    loadResultsCache();
    loadNoteCache();
    loadRetById();


    // Reforço: também tenta carregar do chrome.storage.local (se disponível)
    loadCanceledKeysFromStorage().then(() => { if (!STATE.running) applyCachedTagsToCurrentPage(); }).catch(() => {});
    loadResultsCacheFromStorage().then(() => { if (!STATE.running) applyCachedTagsToCurrentPage(); }).catch(() => {});
    loadNoteCacheFromStorage().then(() => { if (!STATE.running) applyCachedTagsToCurrentPage(); }).catch(() => {});
    loadRetByIdFromStorage().then(() => { if (!STATE.running) applyCachedTagsToCurrentPage(); }).catch(() => {});


    ensureUI();
    ensureRowSelectionHandler();

    const statusEl = document.getElementById('nfse-retencao-status');
    if (statusEl) {
      if (looksLikeNotasPage()) {
        setStatus(statusEl, 'Pronto. Selecione uma ação acima.');
      } else {
                setStatus(statusEl, `Acesse “${notasLabel()}” para iniciar.`);
      }
    }

    // Aplica tags já conhecidas (retenções/canceladas) na página atual
    applyCachedTagsToCurrentPage();

    // Reaplica tags algumas vezes após o carregamento (o portal pode re-renderizar a tabela)
    for (const ms of [200, 800, 1800, 3500]) {
      setTimeout(() => { if (!STATE.running) applyCachedTagsToCurrentPage(); }, ms);
    }

    // Se o usuário trocar de página (paginador), reaplica após a navegação/render
    document.addEventListener('click', (ev) => {
      const a = ev.target && ev.target.closest ? ev.target.closest('.paginacao a') : null;
      if (!a) return;
      // após clique, o portal pode fazer navegação completa ou re-render; tentamos reaplicar
      for (const ms of [300, 1200, 2500]) {
        setTimeout(() => { if (!STATE.running) applyCachedTagsToCurrentPage(); }, ms);
      }
    }, true);

    // Atualiza o total da página atual
    scheduleRenderTotals();
  }

  boot();

    // Observa mudanças na página, mas com debounce para não travar o portal
  let _obsTimer = null;
  let _lastHref = location.href;

  const obs = new MutationObserver(() => {
    // só reage quando não estiver rodando um processo pesado
    if (STATE.running) return;

    // evita loop infinito de re-render
    if (_obsTimer) clearTimeout(_obsTimer);

    _obsTimer = setTimeout(() => {
      // se trocou de página (pg=) ou houve re-render, reaplica tags uma vez
      if (location.href !== _lastHref) _lastHref = location.href;

      ensureUI();
      applyCachedTagsToCurrentPage();
      scheduleRenderTotals();
    }, 450);
  });

  obs.observe(document.documentElement, { childList: true, subtree: true });
})();