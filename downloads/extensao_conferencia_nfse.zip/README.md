# Conferência NFS-e Recebidas (Extensão)

Extensão para o **Emissor Nacional (nfse.gov.br)** que auxilia na conferência das **NFS-e Recebidas**:

- **Analisa retenções** a partir do XML (ISS e federais)
- **Totaliza valores** das notas do período filtrado
- **Exporta XMLs** do período em um único arquivo

## Como instalar (Chrome/Edge)
1. Extraia o arquivo baixado em uma pasta.
2. Abra `chrome://extensions/` (ou `edge://extensions/`).
3. Ative **Modo do desenvolvedor**.
4. Clique em **Carregar sem compactação** e selecione a pasta.

## Como usar
1. Acesse **NFS-e > Recebidas**.
2. Informe o período e clique em **Filtrar**.
3. Use o painel no canto superior direito.

> Dica: você pode **minimizar** o painel e também **arrastar** (clique e arraste em qualquer parte do painel) para não atrapalhar os botões do portal.
